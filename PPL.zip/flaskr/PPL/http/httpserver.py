import os
import sys
import http.server
import socketserver
from os import curdir, sep
import cgi
import subprocess
from http.server import BaseHTTPRequestHandler,HTTPServer
import components.lib.pplUtils as ppl

startupinfo = subprocess.STARTUPINFO()
startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW



print ( ppl.pplRootDir() )


def pplWorker( line ):
    p = []
    k=0
    componentList = line.strip().split('|')
    head = subprocess.Popen(    [
                                    'python',
                                    ppl.pplComponentDir() + 'initStreamStub'
                                ],
                                startupinfo = startupinfo,
                                stdout=subprocess.PIPE
                            )
    for cc in componentList:
        k = componentList.index(cc)
        args = cc.split()
        args.insert( 0, 'python' )
        args[1] = '..' + os.sep + 'components' + os.sep + args[1]
        if k == 0:
            p.append( subprocess.Popen(  args = args, startupinfo = startupinfo, stdin = head.stdout, stdout=subprocess.PIPE ) )
        else:
            p.append( subprocess.Popen(  args = args, startupinfo = startupinfo, stdin =  p[k-1].stdout, stdout=subprocess.PIPE ) )
    return p[k]



class myHandler(http.server.SimpleHTTPRequestHandler):
	
	#Handler for the GET requests
	def do_GET(self):
		print( self.path )
		print( self.path.endswith(".html") )
		if self.path=="/":
			self.path="/index.html"

		try:
			#Check the file extension required and
			#set the right mime type

			sendReply = False
			if self.path.endswith(".html"):
				mimetype='text/html'
				sendReply = True
			if self.path.endswith(".txt"):
				mimetype='text/html'
				sendReply = True
			if self.path.endswith(".jpg"):
				mimetype='image/jpg'
				sendReply = True
			if self.path.endswith(".gif"):
				mimetype='image/gif'
				sendReply = True
			if self.path.endswith(".js"):
				mimetype='application/javascript'
				sendReply = True
			if self.path.endswith(".css"):
				mimetype='text/css'
				sendReply = True

			if sendReply == True:
				#Open the static file requested and send it
				f = open(curdir + sep + self.path, 'rb' ) 
				self.send_response(200)
				self.send_header('Content-type',mimetype)
				self.end_headers()
				self.wfile.write(f.read())
				f.close()
			else:
 				raise IOError
			return


		except IOError:
			self.send_error(404,'File Not Found: %s' % self.path)


        #Handler for the POST requests
	def do_POST(self):
		if self.path=="/ppl":
			form = cgi.FieldStorage(
				fp=self.rfile, 
				headers=self.headers,
				environ={'REQUEST_METHOD':'POST',
		                 'CONTENT_TYPE':self.headers['Content-Type'],
			})

			print ("Your name is: %s" % form["your_name"].value )
			line = "cook rollupTest.txt data |sort Church,Area,Item data|rollup Church,Area qty data|rollup Church qty data|csvToHtml data| serve data "
			# line = "cook rollupTest.txt data |sort Church,Area,Item data | rollup Church:qty data| serve data "

			p = pplWorker(line)

			self.send_response(200)
			self.end_headers()
			# self.wfile.write("Thanks %s !" % form["your_name"].value)
			self.wfile.write(p.communicate()[0])
			return			



HandlerClass = myHandler # SimpleHTTPRequestHandler
ServerClass  = http.server.HTTPServer
port = 8000
with socketserver.TCPServer(("", port), HandlerClass) as httpd:
    print("serving at port", port)
    httpd.serve_forever()




