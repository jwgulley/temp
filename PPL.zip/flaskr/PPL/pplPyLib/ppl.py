
import os
import sys
import subprocess
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'components', 'lib'))
import pplUtils as ppl
pplComponentDir = os.path.join(os.path.dirname(__file__), '..', 'components')

startupinfo = subprocess.STARTUPINFO()
startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

def pplWorker( line ):
    p = []
    k=0
    print( line )
    componentCalls = line.strip().split('|')
    print( componentCalls )
    head = subprocess.Popen( [ 'python', pplComponentDir + os.sep + 'initStreamStub' ], startupinfo = startupinfo, stdout=subprocess.PIPE )
    for cc in componentCalls:
        if cc == '':
            return None
        k = componentCalls.index(cc)
        args = cc.split()
        args.insert( 0, 'python' )
        args[1] = pplComponentDir + os.sep + args[1]
        if k == 0:
            p.append( subprocess.Popen(  args = args, startupinfo = startupinfo, stdin=head.stdout, stdout=subprocess.PIPE ) )
        else:
            p.append( subprocess.Popen(  args = args,
                            startupinfo = startupinfo,
                            stdin =  p[k-1].stdout,                               
                            stdout=subprocess.PIPE ) )
    return p[k]


if __name__ == '__main__':
    line = "cook None rollupTest.txt data | sort data Church,Area,Item data | rollup data Church,Area;qty data| rollup data Church;qty data | csvToHtml data None data | browse data None data"
    p = pplWorker(line)
    if p != None:
        print ( p.communicate()[0] )
        sys.exit(0)


    
