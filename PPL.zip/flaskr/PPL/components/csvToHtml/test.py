import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import pplUtils as ppl
import pplTest

class Test_(pplTest.Test):
    pass
class Test2_(pplTest.Test2):
    pass

# The aim is for this file is identical for all components whose data is
# marshalled using pplCsvFilter.
# run tests with the following from this dir:
# python -m unittest discover
