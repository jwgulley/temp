import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import pplUtils as ppl
import unittest
import logging


# core jdi ("just do it") function
# This sits within a class which is responsible for marshalling data:
# - from the stream to this function;
# - from this function to the stream
# Design concept allows the marshalling code to be re-used and defines an interface by which a workflow ccompiler
# can invoke core functionality when marshalling data more efficiently than is possible using data pipes.

def jdi( lines, paramString  ):
    """ converts csv data in lines to html in stdout"""

    headers = lines[0].split(',')
    
    outputLines = []
    outputLines.append( '<!DOCTYPE html>' )
    outputLines.append(  '<html>' )
    outputLines.append(  '<head>' )
    outputLines.append(  '<style>' )
    outputLines.append(  'table, th, td { border: 1px solid black; }' )
    outputLines.append(  '</style>' )
    outputLines.append(  '</head>' )
    outputLines.append(  '<body>' )

    outputLines.append(  '<H1>Table</H1>' )
    outputLines.append(  '<table style="width:100%">' )
    outputLines.append(  '<tr>' )
    for h in headers:
        outputLines.append(  '<th>{0}</th>'.format(h) )
    outputLines.append(  '</tr>' )

    for line in lines[1:]:
        fields = line.strip().split(',')
        if fields[0][0] == '#':
            outputLines.append(  '<tr>' )
            for f in fields[1:]:
                outputLines.append(  '<td><b>{0}</b></td>'.format(f) )
            continue
            outputLines.append(  '</tr>' )
        outputLines.append(  '<tr>' )
        for f in fields:
            outputLines.append(  '<td>{0}</td>'.format(f) )
        outputLines.append(  '</tr>' )

    outputLines.append(  '</table>' )

    outputLines.append(  '</body>' )

    return outputLines


# list of test cases for the jdi function
jdiTestList = [
    {
        'inputLines' : ( 'tom,dick,harry', '1,2,3', '4,5,6' ),
        'paramString' : '',
        'expectedLines' : ( '<!DOCTYPE html>',
                            '<html>',
                            '<head>',
                            '<style>',
                            'table, th, td { border: 1px solid black; }',
                            '</style>',
                            '</head>',
                            '<body>',
                            '<H1>Table</H1>',
                            '<table style="width:100%">',
                            '<tr>', '<th>tom</th>', '<th>dick</th>', '<th>harry</th>', '</tr>',
                            '<tr>', '<td>1</td>', '<td>2</td>', '<td>3</td>', '</tr>',
                            '<tr>', '<td>4</td>', '<td>5</td>', '<td>6</td>', '</tr>',
                            '</table>',
                            '</body>' ),
    }
]


# basic operation for dev and debug
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    logging.info ( jdi( jdiTestList[0]['inputLines'], jdiTestList[0]['paramString'] ) )

