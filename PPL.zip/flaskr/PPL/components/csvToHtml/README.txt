
Component to convert csv data from a tab on stdin to an html file in a tab on stdout.