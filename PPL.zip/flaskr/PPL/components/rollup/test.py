import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import pplTest

class Test_(pplTest.Test):
    pass
class Test2_(pplTest.Test2):
    pass

# run tests with the following from this dir:
# python -m unittest discover
