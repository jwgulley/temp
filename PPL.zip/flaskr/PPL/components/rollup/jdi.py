import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import pplUtils as ppl
import logging


def jdi( lines, paramString  ):

    def getItem( line, sortHeader, headers ):
        return line.split(',')[headers.index( sortHeader[1:] if '-' in sortHeader else sortHeader )]

    # helper function to initialise the rollup accumulator
    def initialiseRollupAccumulatorDict( factHeaders, rollupAccumulatorDict, initValue ):
        for f in factHeaders:
            rollupAccumulatorDict[f] = initValue 

    # rollup accumulator function
    def accumulateRollup( accumulator, item ):
        return accumulator + float( item )

    # helper function to format the rollup line
    def outputRollup( headers, prevDimDict, rollupAccumulatorDict ):
        fieldList = ['#']
        for h in headers:
            if h in prevDimDict.keys():
                fieldList.append(prevDimDict[h])
            elif h in rollupAccumulatorDict.keys():
                fieldList.append( '{0}'.format( rollupAccumulatorDict[h] ) )
            else:
                fieldList.append('')
        return ','.join( fieldList )


    headers = lines[0].split(',')
    dimHeaders = paramString.split(';')[0].split(',')
    factHeaders = paramString.split(';')[1].split(',')

    logging.debug(headers)
    logging.debug(dimHeaders)
    logging.debug(factHeaders)

    outputLines = []
    outputLines.append( ','.join(headers) )
    prevDimDict = {}
    currDimDict = {}

    rollupAccumulatorDict = {}
    initialiseRollupAccumulatorDict( factHeaders, rollupAccumulatorDict, 0.0 )

    for line in lines[1:]:

        # pass any previous rollups straight through
        fields = line.strip().split(',')
        if fields[0] == '#':
            outputLines.append( line )
            continue

        # dimension dictionary assembly
        prevDimDict = currDimDict
        currDimDict = {}
        for x in dimHeaders:
            currDimDict[x] = getItem( line, x, headers )

        # output rollup and re-initialise following change in dictionary (except for the first line after header)
        if currDimDict != prevDimDict and prevDimDict != {}:
            # put a rollip line in the list for output
            outputLines.append( outputRollup( headers, prevDimDict, rollupAccumulatorDict ) )
            # re-initialise the accumulator
            initialiseRollupAccumulatorDict( factHeaders, rollupAccumulatorDict, 0.0 )

        # accumulate all accumulated columns
        for f in rollupAccumulatorDict.keys():
            rollupAccumulatorDict[f] = accumulateRollup( rollupAccumulatorDict[f], getItem( line, f, headers) )

        # put a normal line in the list for output
        outputLines.append( line ) 

    # put the final rollup line in the list for output
    outputLines.append( outputRollup( headers, prevDimDict, rollupAccumulatorDict ) )

    logging.debug(outputLines)
    return outputLines


jdiTestList = [
    {
        'inputLines' : ('counter,qty', 'A,1', 'A,2', 'B,3', 'B,4'),
        'paramString' : 'counter;qty',
        'expectedLines' : ('counter,qty', 'A,1', 'A,2', '#,A,3.0', 'B,3', 'B,4', '#,B,7.0'),
    }
]

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    logging.info ( jdi( jdiTestList[0]['inputLines'], jdiTestList[0]['paramString'] ) )

