import os
import sys
import io
import contextlib 

import subprocess
import webbrowser
import tempfile

import logging
# logging.basicConfig(level=logging.DEBUG)
# logging.basicConfig(level=logging.INFO)

pplTestMode = 0
pplWorkMode = 1


def pplRootDir():
    return os.environ.get('PPL_ROOT') + os.sep

def pplDataDir():
    return pplRootDir() + 'data' + os.sep

def pplComponentDir():
    return pplRootDir()  + 'components' + os.sep

def pplResultsDir(self):
    return pplRootDir()  + 'results' + os.sep

def pplTempDir(self):
    return pplRootDir()  + 'temp' + os.sep




class pplException( Exception ):
    pass

def pplError( s ):
  callerframerecord = inspect.stack()[1]    # 1 represents line at caller                                         
  frame = callerframerecord[0]
  info = inspect.getframeinfo(frame)
  return 'PPL_OOPS,{0},{1},{2},{3}'.format( s, info.lineno, info.function, info.filename )


def makeStream( lines ):
    return '\n'.join( ['PPL_DATA', '<data>' ] + list(lines) + ['</data>'] )


class pplComponent():

    mode = pplWorkMode
    
    def setTestMode(self):
        self.mode = pplTestMode

    def pplPanic( self, s ):
        if self.mode == pplWorkMode:
            try:
                sys.stdout.write( 'PPL_OOPS\n' )
                sys.stderr.write( '{0}\n'.format(s) )
                sys.exit(1)
            except:
                sys.exit( 'Exeption in pplPanic - abandon all hope :-)\n' )
        elif self.mode == pplTestMpode:
            raise pplException( sr(e) )

    def nullJdi( self, lines ):
        return lines

    def pplStreamRead ( self ):
        try:
            lines = sys.stdin.readlines()
            if lines[0][0:8]== 'PPL_OOPS':
                sys.stdout.write( lines )
                sys.stderr.write( lines )
                sys.exit(1)
            if lines[0][0:8]== 'PPL_DATA':
                strippedLines = []
                for line in lines:
                    strippedLines.append( line.strip() )
                return strippedLines
            else:
                sys.exit(   lines )
        except Exception as e:
            sys.exit( str(e) )

    def pplStreamWrite ( self, lines ):
        try:
            sys.stdout.write( '\n'.join( lines ) )
        except Exception as e:
            sys.exit( str(e) )

    def pplExtractTab( self, lines, tag ):
        tabLines = []
        otherLines = []
        extracting = False
        for line in lines:
            if line.strip() == '<{0}>'.format(tag):
                extracting = True
                continue
            if line.strip() == '</{0}>'.format(tag):
                extracting = False
                continue
            if extracting:
                tabLines.append(line)
            else:
                otherLines.append(line)
        return tabLines, otherLines

    def pplGetCsvHeader( self, lines ):
        headers = lines.pop(0).split(',')
        return headers, lines

    def pplTab( self, tabTag ):
        return '<{0}>'.format( tabTag )

    def pplUntab( self, tabTag ):
        return '</{0}>'.format( tabTag )

    def pplFileRead ( self, pplDataFile ):
        try:
            with open( pplDataFile ) as f:
                lines = f.readlines()
                strippedLines = []
                for line in lines:
                    strippedLines.append( line.strip() )
                return strippedLines
        except Exception as e:
            self.pplPanic( str(e) )    

    def pplFileWrite ( self, lines, pplResultsFile ):
        try:
            with open( self.pplResultsDir() + pplResultsFile, 'w' ) as f:
                f.write(  '\n'.join(lines) )
            return
        except Exception as e:
            self.pplPanic( str(e) )    

    jdi = nullJdi

    def doChunk( self, args ):
        inputLines = self.pplStreamRead()
        try:
            outputLines = self.jdi( args, inputLines )
        except Exception as e:
            self.pplPanic( str(e) )      
        self.pplStreamWrite( outputLines )



    def __init__(self, jdi ):
        if jdi != None:
            self.jdi = jdi


##c = pplComponent( None, None )
##print c.nullTest()

class pplComponentCsvFilter( pplComponent ):

    class pplComponentCsvFilterWrapper():

        def __init__(self, jdi, outer ):
            if jdi != None:
                self.jdi = jdi
            self.outer = outer

        def __call__ ( self, args, inputLines ):

            inputTab = args[1]
            paramString = args[2]
            outputTab = args[3]

            logging.debug(inputTab)
            logging.debug(paramString)
            logging.debug(outputTab)

            logging.debug(str(inputLines) )

            tabLines, outputLines = self.outer.pplExtractTab( inputLines, inputTab )

            tabLines = self.jdi( tabLines, paramString )

            logging.debug(str(tabLines) )

            outputLines.append( self.outer.pplTab( outputTab ) )
            outputLines.extend( tabLines )
            outputLines.append( self.outer.pplUntab( outputTab ) )

            logging.debug(str( outputLines ) )

            return outputLines

    def __init__(self, jdi ):
        if jdi != None:
            wrapper = self.pplComponentCsvFilterWrapper( jdi, self )
            self.jdi = wrapper




class pplComponentCook( pplComponent ):

    def jdi( self, pplArgs, inputLines ):

        pplDataDir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'testData')

        outputLines = inputLines[:]  # NB deep copy (ToDo: Investigate)

        outputLines.append( self.pplTab( pplArgs[3] ) )
        outputLines.extend( self.pplFileRead( pplDataDir + os.sep + pplArgs[2] ) )
        outputLines.append( self.pplUntab( pplArgs[3] ) )

        return outputLines

    def __init__(self ):
        pass


class pplComponentServe( pplComponent ):

    def jdi( self, pplArgs, inputLines ):

        return self.pplExtractTab( inputLines, pplArgs[1] )[0]

    def __init__(self ):
        pass


class pplComponentBrowse( pplComponent ):

    def jdi( self, pplArgs, inputLines ):
        tabLines = self.pplExtractTab( inputLines, pplArgs[1] )[0]
        with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False) as tfn:
            tfn.write( '\n'.join(tabLines) + '\n'  )
            tfn.flush()
            webbrowser.open(  "file://" + tfn.name )
        return inputLines

    def __init__(self ):
        pass


