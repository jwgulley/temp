import unittest
import logging
from jdi import jdi, jdiTestList

# logging.basicConfig(level=logging.DEBUG)

class Test(unittest.TestCase):
    def testSmoke(self):
        for jdiTest in jdiTestList:
            assert jdi ( list( jdiTest['inputLines'] ), jdiTest['paramString'] ) == list( jdiTest['expectedLines'] )



import io
import contextlib
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import pplUtils as ppl

class Test2(unittest.TestCase):
    def testSmoke(self):
        c = ppl.pplComponentCsvFilter(jdi)
        inputStream = ppl.makeStream( jdiTestList[0]['inputLines'] )
        expectedStream = ppl.makeStream( jdiTestList[0]['expectedLines'] )
        sys.stdin = io.StringIO( inputStream )
        with io.StringIO() as buf, contextlib.redirect_stdout(buf):
            c.doChunk( [ '', 'data', jdiTestList[0]['paramString'], 'data' ] )
            outputStream = buf.getvalue()
        assert outputStream == expectedStream


