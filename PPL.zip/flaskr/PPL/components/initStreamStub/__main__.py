import sys
sys.stdout.write('PPL_DATA\n')
