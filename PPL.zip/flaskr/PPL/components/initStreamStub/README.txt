
This is a "terminator" component to initiate a stream with a single magic number.

Data is added using other components - eg the "cook" component to add data from a raw file.

This is needed becuase the cook component may have to add data from an existing stream and will also have to be the first real component of a workflow.

Without any input on a stream, a read will hang.

Flags to make reading an input optional make the component more complicated (?).