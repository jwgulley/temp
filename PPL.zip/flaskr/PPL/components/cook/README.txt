cook component

Enters a raw file onto the stream

Parameters:

- input tab tag - ignored

- name of file to be entered

- output tab tag - ie for the tab in which the data is to be entered


This is a system component implemented in pplUtils.py - no jdi.py needed here.