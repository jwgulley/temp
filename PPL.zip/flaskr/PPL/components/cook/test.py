import os
import sys
import io
import unittest
import contextlib
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import pplUtils as ppl

# List of test cases
# - note use of test file gammadelta.txt
# - there is no meaningful test of the core jdi, so test specified in jdi.py

componentTestList = [
    {
        'inputLines' : (  'PPL_DATA', '<existing>', 'alpha', 'beta', '</existing>' ),
        'paramString' : 'gammadelta.txt',
        'expectedLines' : (  'PPL_DATA', '<existing>', 'alpha', 'beta', '</existing>', '<data>', 'greeks', 'gamma', 'delta', '</data>' ),
    }
]


class TestComponent(unittest.TestCase):
    """ Unittest class to test component outer layer - ie as invoked in a pipeline """

    def testSmokeComponent(self):
        """ Feed data to the invoked component via stdin and confirm data produced as expected """

        # inputStream and outputStream are derived from inner test case via a standard recipe
        inputStream = '\n'.join( list( componentTestList[0]['inputLines']) )
        expectedStream = '\n'.join( list( componentTestList[0]['expectedLines']) )


        # boilerplate use of io module - see on-line documentation
        sys.stdin = io.StringIO( inputStream )
        with io.StringIO() as buf, contextlib.redirect_stdout(buf):
            ppl.pplComponentCook().doChunk( [ 'browse', 'data', componentTestList[0]['paramString'], 'data' ] )
            outputStream = buf.getvalue()
        assert outputStream == expectedStream
