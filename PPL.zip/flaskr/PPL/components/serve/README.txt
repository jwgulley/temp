
serve is a component implemented in pplUtils.py

__main__.py allows it to be invoked in the standard way via a directory name.

Component extracts a tab for a given tag and sends it to standard output

No jdi.py needed, as there is no jdi function to test.

Can only meaningfully test as the component level.
