import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import unittest
import pplUtils as ppl
import io
import contextlib




componentTestList = [
    {
        'inputLines' : (  'PPL_DATA', '<data>', 'alpha', 'beta', '</data>' ),
        'paramString' : 'data',
        'expectedLines' : ( 'alpha', 'beta' ),
    }
]



class Test_Serve(unittest.TestCase):
    """ Unittest class to test component outer layer - ie as invoked in a pipeline """

    def testSmokeComponent(self):
        """ Feed data to the invoked component via stdin and confirm data produced as expected """

        # inputStream and outputStream are derived from inner test case via a standard recipe
        inputStream = '\n'.join(  componentTestList[0]['inputLines'] )
        expectedStream = '\n'.join( componentTestList[0]['expectedLines'] ) 

        # boilerplate use of io module - see on-line documentation
        sys.stdin = io.StringIO( inputStream )
        with io.StringIO() as buf, contextlib.redirect_stdout(buf):
            ppl.pplComponentServe().doChunk( [ '', 'data', componentTestList[0]['paramString'], '' ] )
            outputStream = buf.getvalue()
        assert outputStream == expectedStream

