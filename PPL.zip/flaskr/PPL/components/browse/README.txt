browse component

Invokes a browser to display the data in a tab

Parameters:

- input tab tag - tag of the tab of data to be displayed

- parameters - ignored

- output tab tag - ignored


This is a system component implemented in pplUtils.py, so there is no jdi.py.

Note that this pattern can be extended to invoke other data viewers for use when using components in command line or playpen mode.