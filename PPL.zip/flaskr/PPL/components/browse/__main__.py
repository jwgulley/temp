# Single chunk component run invoked as python <dirname> <parameters>
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import pplUtils as ppl
c = ppl.pplComponentBrowse().doChunk(sys.argv)
