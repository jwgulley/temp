import os
import sys
import logging
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import pplUtils as ppl
import unittest


def jdi( lines, paramString  ):

    getReverseFlag = lambda z: z[0] == '-'
    
    def getItem( line, sortHeader, headers ):
        return line.split(',')[headers.index( sortHeader[1:] if '-' in sortHeader else sortHeader )]

    linesList = list(lines)
    headers = linesList.pop(0).split(',')
    logging.debug(linesList)
    logging.debug(headers)
    logging.debug(paramString)

    sortHeaders = paramString.split(',')

    for sortHeader in reversed( sortHeaders ):
        try:
            linesList.sort( key = lambda x: float( getItem( x, sortHeader, headers ) ), reverse =  getReverseFlag( sortHeader ) )
        except:
            linesList.sort( key = lambda x: getItem( x, sortHeader, headers ), reverse =  getReverseFlag( sortHeader ) )

    outputLines = [ ','.join( headers ) ]
    outputLines.extend( linesList )
    logging.debug(outputLines)

    return outputLines

jdiTestList = [
    {
        'inputLines' : ( 'greeks', 'beta', 'alpha' ),
        'paramString' : 'greeks',
        'expectedLines' : ( 'greeks', 'alpha', 'beta' ),
    }
]

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    logging.info ( jdi( jdiTestList[0]['inputLines'], jdiTestList[0]['paramString'] ) )


