import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
import jdi
import pplUtils as ppl
ppl.pplComponentCsvFilter( jdi.jdi ).doChunk( sys.argv )
