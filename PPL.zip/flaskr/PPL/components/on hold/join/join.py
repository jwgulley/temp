# To Do: read and write Header

import sys


lineList1 = list()
for line in sys.stdin:
    if line == '<file>\n':
        continue
    if line == '</file>\n':
        break
    fields = list()
    for field in line.strip().split(','):
        fields.append(field)
    lineList1.append(fields)

lineList2 = list()
for line in sys.stdin:
    if line == '<file>\n':
        continue
    if line == '</file>\n':
        break
    fields = list()
    for field in line.strip().split(','):
        fields.append(field)
    lineList2.append(fields)

sys.stdout.write( '<file>\n' )
for line1 in lineList1:
    for line2 in lineList2:
        if line1[0] == line2[0]:
            sys.stdout.write( '{0}'.format(line1[0] ) )
            for field in line1[1:]:
                sys.stdout.write( ',{0}'.format(field) )
            for field in line2[1:]:
                sys.stdout.write( ',{0}'.format(field) )
            sys.stdout.write( '\n' )

sys.stdout.write( '</file>\n' )
