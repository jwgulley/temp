import os
import sys
lines = sys.stdin.readlines()
extracting = False

with open( '..' + os.sep + 'results' + os.sep + sys.argv[2], 'w') as f:
    for line in lines:
        if line.strip() == '<{0}>'.format(sys.argv[1]):
            extracting = True
            continue
        if line.strip() == '</{0}>'.format(sys.argv[1]):
            extracting = False
            continue
        if extracting:
            f.write(line)
        else:
            sys.stdout.write(line)
