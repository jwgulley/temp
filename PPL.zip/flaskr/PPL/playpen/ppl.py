import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'components', 'lib'))
pplComponentDir = os.path.join(os.path.dirname(__file__), '..', 'components' )
import pplUtils as ppl

import logging

logging.basicConfig(level=logging.DEBUG)

logging.debug( sys.argv[1] )
( dname, fname ) = os.path.split( sys.argv[1] )
logging.debug( dname )
logging.debug( fname )
( fbase, fext ) = os.path.splitext( fname )
logging.debug( fbase )
logging.debug( fext )
fbaseList = fbase.split('_')
logging.debug( fbaseList[0] )
logging.debug( fbaseList[1:] )
line = fbaseList[0]
component = fbaseList[1]
args = fbaseList[1:]

newLine = '{0:02}'.format( int( line ) + 1 )
logging.debug( newLine )

logging.debug( 'type ' + line + '.txt | ' + 'python ' + pplComponentDir + os.sep + component + ' ' + ' '.join(args[1:]) + ' > ' + newLine + '.txt' )
os.system( 'type ' + line + '.txt | ' + 'python ' + pplComponentDir + os.sep + component + ' ' + ' '.join(args[1:]) + ' > ' + newLine + '.txt' )
# input( 'return to exit...')

